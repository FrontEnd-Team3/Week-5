const Images = () => {
  return <img src="img/main_visual.jpg" />;
};
export default Images;
