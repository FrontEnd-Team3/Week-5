import Button from "./style";

const BasicButton = ({ size, variant }) => {
  return <Button size={size} variant={variant}></Button>;
};

export default BasicButton;
