import styled from "styled-components";
import Visual from "./Visual";

const MainPage = () => {
  return (
    <div>
      <main>
        <Visual></Visual>
      </main>
    </div>
  );
};
export default MainPage;
